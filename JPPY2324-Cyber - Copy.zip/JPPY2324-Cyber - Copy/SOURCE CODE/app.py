from flask import Flask, request, render_template, redirect, url_for
import numpy as np
import pandas as pd
from sklearn import metrics 
import warnings
import re
import pymsgbox

import pickle
warnings.filterwarnings('ignore')


pickle_in = open('model.pkl','rb')
pac = pickle.load(pickle_in)
tfid = open('tfidf_vectorizer.pkl','rb')
tfidf_vectorizer = pickle.load(tfid)


app = Flask(__name__)


@app.route('/')
@app.route('/welcome')
def welcome():
    return render_template('welcome.html')

@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/admin')
def admin():
    return render_template('admin.html')

@app.route('/superadmin')
def superadmin():
    return render_template('superadmin.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        profile = request.form.get('profile')

     # Redirect based on profile type
        if profile == "admin":
            return redirect(url_for('admin'))
        elif profile == "super_admin":
            return redirect(url_for('superadmin'))
        else:
            return redirect(url_for('home'))
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        profile = request.form.get('profile')

        # Redirect based on profile type
        if profile == "admin":
            return redirect(url_for('admin'))
        elif profile == "super_admin":
            return redirect(url_for('superadmin'))
        else:
            return redirect(url_for('home'))

    # If it's a GET request, render the signup page
    return render_template('signup.html')

@app.route('/logout')
def logout():
    session.clear()  # Clear session on logout
    return redirect(url_for('welcome'))  # Redirect to welcome page

@app.route('/upload')
def upload():
    return render_template('upload.html')

@app.route('/preview', methods=["POST"])
def preview():
    if request.method == 'POST':
        dataset = request.files['datasetfile']
        df = pd.read_csv(dataset, encoding='unicode_escape')
        df.set_index('Id', inplace=True)
        return render_template("preview.html", df_view=df)
    
@app.route('/prediction', methods=["GET", "POST"])
def prediction():
    if request.method == "POST":
        url = request.form['url'].strip()
        print(f"Processing URL: {url}")
        
        if not url:
            return render_template('prediction.html', error="Please enter a URL")
        
        try:
            # Use the URL directly instead of regex extraction
            input_data = [url]
            
            # Transform using TF-IDF
            tfidf_test = tfidf_vectorizer.transform(input_data)
            
            # Get raw prediction
            y_pred = pac.predict(tfidf_test)
            print(f"Raw prediction: {y_pred}, Type: {type(y_pred[0])}")
            
            # Handle different possible output formats
            if isinstance(y_pred[0], (int, np.integer)):
                # If model outputs integers (0/1)
                pred = "Phishing" if y_pred[0] == 1 else "Legitimate"
            elif isinstance(y_pred[0], str):
                # If model outputs strings ('good'/'bad')
                pred = "Phishing" if y_pred[0].lower() in ['bad', 'malware', 'phishing'] else "Legitimate"
            else:
                # Default case
                pred = str(y_pred[0])
            
            print(f"Final prediction: {pred}")
            return render_template('prediction.html', preds=pred, url=url)
        
        except Exception as e:
            print(f"Error during prediction: {str(e)}")
            return render_template('prediction.html', error=f"Error: {str(e)}")
    
    return render_template('prediction.html')


if __name__ == "__main__":
    app.run(debug=True)
