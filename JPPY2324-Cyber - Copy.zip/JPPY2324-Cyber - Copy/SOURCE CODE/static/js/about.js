document.addEventListener("DOMContentLoaded", function() {
    console.log("About Us page loaded!");
});
