// Logout functionality
document.addEventListener('DOMContentLoaded', function() {
    // Ensure the button exists before adding event listener
    const logoutButton = document.querySelector('.logout-btn');
    if (logoutButton) {
        logoutButton.addEventListener('click', function() {
            // Redirect to the /logout route
            window.location.href = '/welcome';  // This will trigger the Flask route to logout and redirect
        });
    }
});
