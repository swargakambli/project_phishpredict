document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("predictForm").onsubmit = function () {
        let url = document.getElementById("url").value;
        if (url === "") {
            alert("Please enter a URL!");
            return false;
        }
        return true;
    };
});
