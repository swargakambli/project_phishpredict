document.getElementById("loginBtn").addEventListener("click", function(event) {
    event.preventDefault();  // Prevent form submission until validation is done

    let userId = document.getElementById("userId").value;
    let role = document.getElementById("profile").value;  // Make sure the ID is 'profile' from HTML

    // Check if User ID is provided
    if (!userId) {
        alert("Please enter your User ID.");
        return;
    }

    // Redirect based on role
    if (role === "admin") {
        window.location.href = "/admin";  // Redirect to the admin page
    } else if (role === "super_admin") {
        window.location.href = "/superadmin";  // Redirect to the super admin page
    } else {
        window.location.href = "/home";  // Redirect to home for regular users
    }
});

// OPTIONAL: Highlight the role selection dropdown when changed
document.getElementById("profile").addEventListener("change", function() {
    this.style.border = "2px solid #4CAF50"; // Green border when selected
});
