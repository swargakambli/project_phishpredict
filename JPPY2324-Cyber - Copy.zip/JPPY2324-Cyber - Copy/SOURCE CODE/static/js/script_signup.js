function handleSignup() {
    // Get form values
    let profile = document.getElementById("profile").value;
    let email = document.getElementById("email").value;
    let userId = document.getElementById("userId").value;
    let password = document.getElementById("password").value;
    let confirmPassword = document.getElementById("confirmPassword").value;

    // Basic validation check
    if (!email || !userId || !password || !confirmPassword) {
        alert("Please fill in all fields.");
        return;
    }

    if (password !== confirmPassword) {
        alert("Passwords do not match.");
        return;
    }

    // Simulate signup process (Replace this with actual backend integration)
    alert("Signup successful! Redirecting...");

    // Redirect based on selected profile
    if (profile === "admin") {
        window.location.href = "/admin";  // Redirect to admin dashboard
    } else if (profile === "super_admin") {
        window.location.href = "/superadmin";  // Redirect to super admin dashboard
    } else {
        window.location.href = "/";  // Redirect to home page for normal users
    }
}
